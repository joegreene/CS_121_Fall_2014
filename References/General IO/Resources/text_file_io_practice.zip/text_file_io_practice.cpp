/*
  Name: Joe Greene
  Program: Text File IO Practice
  Purpose: To grab the first line of an input text file and output it to another
  Notes:
    - This program uses basic text file IO commands
    - This program uses functions and function prototypes
    - Make sure "input_test.txt" is in the same directory as wherever your source code's file is
      - ex) For me the directory where both files went is (on a Windows 7 Computer):
        C:\Users\Joe\Documents\Visual Studio 2010\Projects\text_file_io_practice\text_file_io_practice
        NOTE: It should be the same folder as wherever you made your main.cpp
        NOTE 2: I've included an image as well if in case you're stuck.
    - General Tips:
      - Don't just copy + paste the code: Type it out yourself to
        better familiarize yourself with it
      - Try renaming the file names and string variables to get an 
        idea of what's going on.
*/
#include <iostream> //by now you should know what this is
#include <fstream>  //file stream library
#include <string>   //library to use strings

using namespace std;

//Function Prototypes
string read_file(string fn);                //custom function that reads files given a file name string
void write_to_file(string fn, string msg);  //"                  " writes to a file given a file name and message

int main()
{
  string file_name = "input_test.txt";         //set up file name for reading from initial file
  string message = read_file(file_name);       //call the read_file function

  if(message != "NULL")                        //if read_file didn't produce an error
  {
    string new_file_name = "output_test.txt";  //set up file name for outputting message
    write_to_file(new_file_name, message);     //call the write_to_file function
  }

  //Custom "system("pause");" function that works for more than just Windows
  cout << "Press ENTER to exit program...";
  cin.ignore();

  return 0;
}

string read_file(string fn)
{
  ifstream input_file;            //input file object to be used
  input_file.open(fn.c_str());    //open (argument is a c-string, not string (distinction will be made later)), step 1

  string message = "";            //message to write to

  if(input_file.is_open())        //if the input file was opened successfully, step 2
  {
    getline(input_file, message); //grab first line of input file, step 2i
    input_file.close();           //close file, step 2ii
    cout << "Read input file successfully.\n"; //optional message (for debug)
  }
  else
  {
    cout << "ERROR: File could not be opened to extract data.\n"; //error message, step 3
    message = "NULL";             //set message to NULL to skip writing to file later on
  }

  return message; //return new message to be outputted
}

void write_to_file(string fn, string msg)
{
  ofstream output_file;          //output file object to be used
  output_file.open(fn.c_str());  //open (argument is a c-string, not string (distinction will be made later)), step 1

  if(output_file.is_open())      //if the output file was successfully opened (or made), step 2
  {
    output_file << msg;          //write string to output file, step 2i
    output_file.close();         //close file, step 2ii
    cout << "Wrote to output file successfully.\n"; //optional message (for debug)
  }
  else
  {
    cout << "ERROR: Issue when writing to file.\n"; //error message, step 3
  }
}